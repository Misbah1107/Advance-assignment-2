    //  Q1

// function afterSecond(){
    
//     var date = new Date();
//     var time = date.getHours();
//     var min = date.getMinutes();
//     var sec = date.getSeconds();
//     console.log( `${time}:${min}:${sec}`);
     
// }
// setInterval(afterSecond, 1000);


//    Q2

// yourName = () =>{
//  var name = prompt("Enter your name");
//  var a = name.slice(0, 1).toUpperCase();
//  var b = name.slice(1, name.length).toLowerCase();
//  var c = a + b;
//  console.log(`Hello ${c} thanks to visit our website.`);
// }
// yourName();


//    Q3

// sum = () => {
//     return 2 + 2;
// }
// var a = sum();
// console.log(a);


    //  Q4

// multiply = () => {
//     let p = +prompt('Enter number please');
//     let newValue = p * 0.5;
//     return newValue;
// }
// let a = multiply();
// console.log(a);

   
    //  Q5

// var array = [1, 2, 3, 4, 5, 6];
//  let a = array.map((a) =>{
//     console.log(a);
//  });


    //   Q6

// let records = [
//     {id: 1, name: 'Misbah'},
//     {id: 2, name: 'Hiba'},
//     {id: 3, name: 'Uroosa'},
//     {id: 4, name: 'Ariba'},
//     {id: 5, name: 'Hermain'}
// ];

// let map = records.map((map) => {
//     console.log(map)
// });
